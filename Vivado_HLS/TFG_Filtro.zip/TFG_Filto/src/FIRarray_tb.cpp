/**************************************************************
� testbench_FIR.cpp
� author    Daniel Garc�a
� date      2026-04-22
� description:
    Testbench para el filtro FIR multicanal.
    Lee un archivo de texto con muestras de 24 bits (formato x"XXXXXXXX")
    y comprueba el comportamiento del filtro, mostrando la salida
    cuando se detectan cambios o cada cierto n�mero de muestras.
*************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "FIR.h"
#include "config.h"
#include "hls_stream.h"
#include <ap_int.h>

int main() {
    // 1. APERTURA DEL ARCHIVO DE ENTRADA
    FILE *fin = fopen("datain_ch9_buenos.txt", "r");
    if (!fin) {
        printf("ERROR: No se pudo abrir 'datain_ch9_buenos.txt'.\n");
        printf("       Aseg�rese de que el archivo existe en el directorio del proyecto.\n");
        return 1;
    }

    // 2. DECLARACI�N DE STREAMS Y VARIABLES
    hls::stream<TL_data_raw>    data_in_stream;   // Stream de entrada (24 bits)
    hls::stream<axis_out_t> data_out_stream;  // Stream de salida (8 bits + TLAST)

    // Umbrales para cada canal (se pueden cargar desde archivo si se desea)
    Q_suma umbral[num_canales];
    for (int i = 0; i < num_canales; i++) {
        umbral[i] = (Q_suma)0.015;   // Valor de ejemplo, ajustar seg�n la aplicaci�n
    }

    // Variables para lectura del archivo
    char linea[128];
    unsigned long long temp_in;

    // Contador de muestras procesadas
    int n = 0;

    // Para control de impresi�n de cambios
    T_out_8bit last_salida = 0;
    int last_print_n = -1000;

    // 3. CABECERA DE LA SALIDA
    printf("\n");
    printf("SIMULACION DEL FILTRO FIR MULTICANAL\n");
    printf("====================================\n");
    printf("Archivo de entrada: datain_ch9_buenos.txt\n");
    printf("Umbrales: ");
    for (int i = 0; i < num_canales; i++) {
        printf("Ch%d=%.4f ", i, (double)umbral[i]);
    }
    printf("\n\n");

    printf("   n     | pkt | Ch |  salida (bin)   | hex  | TLAST\n");
    printf("---------|-----|----|-----------------|------|-------\n");

    // 4. BUCLE PRINCIPAL DE PROCESAMIENTO
    #ifdef signal_length
        int max_samples = signal_length;
    #else
        int max_samples = 1000000;   // l�mite de seguridad
    #endif

    for (n = 0; n < max_samples; n++) {
        // 4.1 Lectura de una l�nea del archivo
        if (fscanf(fin, "%s", linea) != 1) {
            break;   // Fin de archivo
        }

        // Convertir de cadena hexadecimal (formato x"XXXXXXXX") a entero
        if (sscanf(linea, "x\"%llx\"", &temp_in) != 1) {
            printf("ERROR: Formato incorrecto en la l�nea %d: %s\n", n+1, linea);
            break;
        }

        // 4.2 Crear muestra de 24 bits y enviarla al stream
        TL_data_raw muestra_32bits = 0;
        muestra_32bits.range(23, 0) = (ap_uint<24>)temp_in;

        // Enviamos la palabra de 32 bits al stream
        data_in_stream.write(muestra_32bits);

        // 4.3 Llamar al filtro (procesa UNA palabra del stream)
        FIR_filter(data_in_stream, data_out_stream, umbral);

        // 4.4 Leer la salida generada (siempre hay una por cada llamada)
        if (!data_out_stream.empty()) {
            axis_out_t out_val = data_out_stream.read();
            T_out_8bit salida_byte = out_val.data;
            int tlast = out_val.last;
            int pos_trama = n % 9;

            if (salida_byte != last_salida ||
                n - last_print_n > 1000 ||
                tlast == 1) {

                // Imprimir n�mero de muestra y posici�n en trama
                printf("%8d | %3d |", n, pos_trama);

                // Indicar el canal si la posici�n corresponde a un canal (1..8)
                if (pos_trama >= 1 && pos_trama <= num_canales) {
                    printf(" %2d |", pos_trama - 1);
                } else {
                    printf(" -- |");
                }

                // Imprimir la salida en binario (bit a bit)
                printf(" ");
                for (int bit = 7; bit >= 0; bit--) {
                    printf("%d", (int)((salida_byte >> bit) & 1));
                }
                printf(" | 0x%02X |", (unsigned)salida_byte);

                // Indicar si es final de trama
                if (tlast) {
                    printf("  SI   ");
                } else {
                    printf("  NO   ");
                }
                printf("\n");

                last_salida = salida_byte;
                last_print_n = n;
            }
        } else {
            printf("ERROR: No hay dato de salida en la iteraci�n %d\n", n);
        }
    }

    // 5. FINALIZACI�N
    fclose(fin);
    printf("\nProcesadas %d muestras.\n", n);
    printf("SIMULACION FINALIZADA CON EXITO.\n");
    return 0;
}
