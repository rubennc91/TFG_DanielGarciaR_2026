<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="com.autoesl.autopilot.project" name="TFG_Filto" top="FIR_filter">
  <files>
    <file name="../src/datain_ch9_buenos.txt" sc="0" tb="1" cflags=" -Wno-unknown-pragmas" blackbox="false" csimflags=" -Wno-unknown-pragmas"/>
    <file name="../src/FIRarray_tb.cpp" sc="0" tb="1" cflags=" -Wno-unknown-pragmas" blackbox="false" csimflags=" -Wno-unknown-pragmas"/>
    <file name="TFG_Filto/src/config.h" sc="0" tb="false" cflags="" blackbox="false" csimflags=""/>
    <file name="TFG_Filto/src/FIRarray.cpp" sc="0" tb="false" cflags="" blackbox="false" csimflags=""/>
    <file name="TFG_Filto/src/FIR.h" sc="0" tb="false" cflags="" blackbox="false" csimflags=""/>
  </files>
  <solutions>
    <solution name="solution1" status="active"/>
  </solutions>
  <includePaths/>
  <libraryPaths/>
  <Simulation>
    <SimFlow name="csim" csimMode="0" lastCsimMode="0"/>
  </Simulation>
</project>
