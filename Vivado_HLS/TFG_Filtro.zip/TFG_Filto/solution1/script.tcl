############################################################
## This file is generated automatically by Vivado HLS.
## Please DO NOT edit it.
## Copyright (C) 1986-2019 Xilinx, Inc. All Rights Reserved.
############################################################
open_project TFG_Filto
set_top FIR_filter
add_files TFG_Filto/src/config.h
add_files TFG_Filto/src/FIRarray.cpp
add_files TFG_Filto/src/FIR.h
add_files -tb TFG_Filto/src/datain_ch9_buenos.txt -cflags "-Wno-unknown-pragmas" -csimflags "-Wno-unknown-pragmas"
add_files -tb TFG_Filto/src/FIRarray_tb.cpp -cflags "-Wno-unknown-pragmas" -csimflags "-Wno-unknown-pragmas"
open_solution "solution1"
set_part {xc7z010-clg225-1}
create_clock -period 10 -name default
config_export -format ip_catalog -rtl vhdl
#source "./TFG_Filto/solution1/directives.tcl"
csim_design
csynth_design
cosim_design -rtl vhdl
export_design -flow impl -rtl vhdl -format ip_catalog
