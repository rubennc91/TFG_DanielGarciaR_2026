<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="com.autoesl.autopilot.project" name="FIR_TFM" top="FIR_filter_tfm">
  <files>
    <file name="../src/datain_ch9_buenos.txt" sc="0" tb="1" cflags=" -Wno-unknown-pragmas" blackbox="false" csimflags=" -Wno-unknown-pragmas"/>
    <file name="../src/FIR_filter_tb.cpp" sc="0" tb="1" cflags=" -Wno-unknown-pragmas" blackbox="false" csimflags=" -Wno-unknown-pragmas"/>
    <file name="FIR_TFM/src/config.h" sc="0" tb="false" cflags="" blackbox="false" csimflags=""/>
    <file name="FIR_TFM/src/FIR_tfm.cpp" sc="0" tb="false" cflags="" blackbox="false" csimflags=""/>
    <file name="FIR_TFM/src/FIR_filter.h" sc="0" tb="false" cflags="" blackbox="false" csimflags=""/>
  </files>
  <solutions>
    <solution name="solution1" status="active"/>
  </solutions>
  <includePaths/>
  <libraryPaths/>
  <Simulation>
    <SimFlow name="csim" csimMode="0" lastCsimMode="0"/>
  </Simulation>
</project>
