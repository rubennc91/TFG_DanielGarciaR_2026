############################################################
## This file is generated automatically by Vivado HLS.
## Please DO NOT edit it.
## Copyright (C) 1986-2019 Xilinx, Inc. All Rights Reserved.
############################################################
open_project FIR_TFM
set_top FIR_filter_tfm
add_files FIR_TFM/src/config.h
add_files FIR_TFM/src/FIR_tfm.cpp
add_files FIR_TFM/src/FIR_filter.h
add_files -tb FIR_TFM/src/datain_ch9_buenos.txt -cflags "-Wno-unknown-pragmas" -csimflags "-Wno-unknown-pragmas"
add_files -tb FIR_TFM/src/FIR_filter_tb.cpp -cflags "-Wno-unknown-pragmas" -csimflags "-Wno-unknown-pragmas"
open_solution "solution1"
set_part {xc7z010-clg225-1}
create_clock -period 10 -name default
config_export -format ip_catalog -rtl vhdl
#source "./FIR_TFM/solution1/directives.tcl"
csim_design
csynth_design
cosim_design -rtl vhdl
export_design -flow impl -rtl vhdl -format ip_catalog
